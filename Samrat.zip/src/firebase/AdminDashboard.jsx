import React, { useState, useEffect } from 'react';
import { getAuth, signInWithEmailAndPassword } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';
import {
  getFirestore,
  collection,
  addDoc,
  deleteDoc,
  doc,
  onSnapshot,
  updateDoc,
} from 'firebase/firestore';
import {
  getStorage,
  ref,
  uploadBytes,
  getDownloadURL,
} from 'firebase/storage';
import { app } from './firebase';
import './AdminDashboard.css';

const AdminDashboard = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [user, setUser] = useState(null);
  const [backgroundImage, setBackgroundImage] = useState(null);
  const [newBackgroundImage, setNewBackgroundImage] = useState(null);
  const [orders, setOrders] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [newItem, setNewItem] = useState({ name: '', price: '', image: null });

  const navigate = useNavigate();
  const auth = getAuth(app);
  const db = getFirestore(app);
  const storage = getStorage(app);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (authUser) => {
      if (authUser) {
        if (authUser.email === 'meetkhaire037@gmail.com') {
          setUser(authUser);
          fetchBackgroundImage();
          fetchOrders();
          fetchMenuItems();
        } else {
          setError('Unauthorized Access');
          await auth.signOut();
        }
      } else {
        setUser(null);
      }
    });
    return () => unsubscribe();
  }, []);

  const fetchBackgroundImage = async () => {
    try {
      const storageRef = ref(storage, 'homepage/background.jpg');
      const url = await getDownloadURL(storageRef);
      setBackgroundImage(url);
    } catch (err) {
      console.error('Error fetching background image:', err);
    }
  };

  const fetchOrders = () => {
    const unsubscribe = onSnapshot(collection(db, 'orders'), (snapshot) => {
      const fetchedOrders = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setOrders(fetchedOrders);
    });
    return () => unsubscribe();
  };

  const fetchMenuItems = () => {
    const unsubscribe = onSnapshot(collection(db, 'menu'), (snapshot) => {
      const fetchedItems = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMenuItems(fetchedItems);
    });
    return () => unsubscribe();
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await signInWithEmailAndPassword(auth, email, password);
      if (email !== 'meetkhaire037@gmail.com') {
        setError('Unauthorized Access');
        await auth.signOut();
      }
    } catch (err) {
      setError(err.message);
    }
  };

  const handleImageUpload = async () => {
    if (!newBackgroundImage) return;
    const storageRef = ref(storage, `homepage/${new Date().getTime()}-${newBackgroundImage.name}`);
    await uploadBytes(storageRef, newBackgroundImage);
    const downloadURL = await getDownloadURL(storageRef);

    try {
      await updateDoc(doc(db, 'settings', 'homepage'), {
        backgroundImage: downloadURL,
      });
      setBackgroundImage(downloadURL);
      setNewBackgroundImage(null);
    } catch (dbError) {
      console.error('Error updating background image URL:', dbError);
    }
  };

  const updateOrderStatus = async (orderId, newStatus) => {
    try {
      await updateDoc(doc(db, 'orders', orderId), { status: newStatus });
    } catch (error) {
      console.error('Error updating order status:', error);
    }
  };

  const addItemToMenu = async () => {
    try {
      let imageUrl = '';
      if (newItem.image) {
        const storageRef = ref(storage, `menu/${newItem.image.name}`);
        await uploadBytes(storageRef, newItem.image);
        imageUrl = await getDownloadURL(storageRef);
      }

      await addDoc(collection(db, 'menu'), {
        name: newItem.name,
        price: newItem.price,
        image: imageUrl,
      });

      setNewItem({ name: '', price: '', image: null });
    } catch (error) {
      console.error('Error adding item:', error);
    }
  };

  const deleteMenuItem = async (id) => {
    try {
      await deleteDoc(doc(db, 'menu', id));
    } catch (error) {
      console.error('Error deleting item:', error);
    }
  };

  if (!user) {
    return (
      <div className="admin-container">
        <h2 className="admin-heading">Admin Login</h2>
        {error && <p className="admin-error">{error}</p>}
        <form onSubmit={handleLogin} className="admin-form">
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="admin-input"
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="admin-input"
          />
          <button type="submit" className="admin-button">Login</button>
        </form>
      </div>
    );
  }

  return (
    <div className="admin-container">
      <h2 className="admin-heading">Admin Dashboard</h2>

      <div className="admin-section">
        <h3 className="admin-section-title">Change Homepage Background</h3>
        {backgroundImage && <img src={backgroundImage} alt="Background" className="admin-background-image" />}
        <input type="file" onChange={(e) => setNewBackgroundImage(e.target.files[0])} className="admin-input" />
        <button onClick={handleImageUpload} className="admin-button">Upload and Change</button>
      </div>

      <div className="admin-section">
        <h3 className="admin-section-title">Order Management</h3>
        {orders.map((order) => (
          <div key={order.id} className="admin-order">
            <p>Order ID: <span className="admin-order-id">{order.id}</span></p>
            <p>Status: <span className="admin-order-status">{order.status}</span></p>
            <select
              value={order.status}
              onChange={(e) => updateOrderStatus(order.id, e.target.value)}
              className="admin-select"
            >
              <option value="Pending">Pending</option>
              <option value="Preparing">Preparing</option>
              <option value="Out for Delivery">Out for Delivery</option>
              <option value="Order Completed">Order Completed</option>
            </select>
          </div>
        ))}
      </div>

      <div className="admin-section">
        <h3 className="admin-section-title">Menu Management</h3>
        <input
          placeholder="Item Name"
          value={newItem.name}
          onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
          className="admin-input"
        />
        <input
          placeholder="Price"
          type="number"
          value={newItem.price}
          onChange={(e) => setNewItem({ ...newItem, price: e.target.value })}
          className="admin-input"
        />
        <input
          type="file"
          onChange={(e) => setNewItem({ ...newItem, image: e.target.files[0] })}
          className="admin-input"
        />
        <button onClick={addItemToMenu} className="admin-button">Add Item</button>

        {menuItems.map((item) => (
          <div key={item.id} className="admin-menu-item">
            <p>{item.name} - ₹{item.price}</p>
            <p style={{ color: 'gray', fontStyle: 'italic' }}>Image not loaded due to CORS issue.</p>
            <button onClick={() => deleteMenuItem(item.id)} className="admin-delete-button">Delete</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminDashboard;
